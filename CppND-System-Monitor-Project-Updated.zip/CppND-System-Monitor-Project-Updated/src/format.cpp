#include <string>

#include "format.h"

using std::string;

// TODO: Complete this helper function
// INPUT: Long int measuring seconds
// OUTPUT: HH:MM:SS
// REMOVE: [[maybe_unused]] once you define the function
string Format::ElapsedTime(long seconds) { 
     int hour,minute,sec;
     string str_hour="";
     string str_minute="";
     string str_sec="";
    hour=seconds/3600;
    seconds=seconds%3600;
    minute=seconds/60;
    seconds=seconds%60;
    sec=seconds;
    str_hour= hour<10?"0"+std::to_string(hour):std::to_string(hour);
    str_minute= minute<10?"0"+std::to_string(minute):std::to_string(minute);
    str_sec=sec<10?"0"+std::to_string(sec):std::to_string(sec);
    return str_hour+":"+str_minute+":"+str_sec;
    }